<?php include('db_connect.php');
$cat = $conn->query("SELECT * FROM room_categories");
$cat_arr = array();
while ($row = $cat->fetch_assoc()) {
	$cat_arr[$row['id']] = $row;
}
$room = $conn->query("SELECT * FROM rooms");
$room_arr = array();
while ($row = $room->fetch_assoc()) {
	$room_arr[$row['id']] = $row;
}
?>
<style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #007bff;
            color: #fff;
        }
        tr:hover {
            background-color: #f2f2f2;
        }
    </style>

<div class="container-fluid">
	<div class="col-lg-12">
		<div class="row mt-3">
			<div class="col-md-12">
				<div class="card">
					<div class="card-body">
						<table class="table table-bordered">
							<thead>
								<th class="text-center">No</th>
								<th class="text-center">Category</th>
								<th class="text-center">Room</th>
								<th class="text-center">Reference</th>
								<th class="text-center">Status</th>
								<th class="text-center">Action</th>
							</thead>
							<tbody>
								<?php
								$i = 1;
								$checked = $conn->query("SELECT * FROM checked where status != 0 order by status desc, id asc ");
								while ($row = $checked->fetch_assoc()):
									?>
									<tr>
										<td class="text-center">
											<?php echo $i++ ?>
										</td>
										<td class="text-center">
											<?php
											if (isset($row['room_id']) && isset($room_arr[$row['room_id']]) && isset($cat_arr[$room_arr[$row['room_id']]['category_id']]['name'])) {
												echo $cat_arr[$room_arr[$row['room_id']]['category_id']]['name'];
											} else {
												echo 'Category not found';
											}
											?>
										</td>
										<td class="text-center">
											<?php
											if (isset($row['room_id']) && isset($room_arr[$row['room_id']]['room'])) {
												echo $room_arr[$row['room_id']]['room'];
											} else {
												echo 'Room not found';
											}
											?>
										</td>
										<td class="text-center">
											<?php echo isset($row['ref_no']) ? $row['ref_no'] : 'Ref no not found'; ?>
										</td>
										<?php if ($row['status'] == 1): ?>
											<td class="text-center"><span class="badge badge-warning">Checked-IN</span></td>
										<?php else: ?>
											<td class="text-center"><span class="badge badge-success">Checked-Out</span></td>
										<?php endif; ?>
										<td class="text-center">
											<button class="btn btn-sm btn-primary check_out" type="button"
												data-id="<?php echo $row['id'] ?>">View</button>
										</td>

									</tr>
								<?php endwhile; ?>

							</tbody>
						</table>
						<button class="btn btn-primary mb-3" onclick="printTable()">Print Data</button>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script>
   function printTable() {
        // Salin tabel yang terlihat ke jendela baru
        var printWindow = window.open('', '_blank');
        var tableClone = $('table').clone();

        // Hapus kolom "Action" dari tabel kloning
        tableClone.find('thead th:last-child, tbody td:last-child').remove();

        // Tambahkan tabel kloning ke jendela baru
        $(printWindow.document.body).html(tableClone);

        // Cetak tabel dari jendela baru
        printWindow.document.head.innerHTML = '<title>Data Print</title>';
        printWindow.print();
        printWindow.close();
    }
    
	$('table').dataTable()
	$('.check_out').click(function () {
		uni_modal("Check Out", "manage_check_out.php?checkout=1&id=" + $(this).attr("data-id"))
	})
	$('#filter').submit(function (e) {
		e.preventDefault()
		location.replace('index.php?page=check_in&category_id=' + $(this).find('[name="category_id"]').val() + '&status=' + $(this).find('[name="status"]').val())
	})
</script>