<?php include('db_connect.php');
$cat = $conn->query("SELECT * FROM room_categories");
$cat_arr = array();
while ($row = $cat->fetch_assoc()) {
	$cat_arr[$row['id']] = $row;
}
$room = $conn->query("SELECT * FROM rooms");
$room_arr = array();
while ($row = $room->fetch_assoc()) {
	$room_arr[$row['id']] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #007bff;
            color: #fff;
        }
        tr:hover {
            background-color: #f2f2f2;
            transition: background-color 0.3s ease;
        }
        .badge {
            padding: 6px 12px;
            border-radius: 5px;
            font-size: 14px;
        }
        .badge-warning {
            background-color: #ffc107;
            color: #333;
        }
        .badge-success {
            background-color: #28a745;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Admin Dashboard</h2>
        <table>
            <thead>
                <tr>
                    <th class="text-center">Category</th>
                    <th class="text-center">Room</th>
                    <th class="text-center">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $checked = $conn->query("SELECT * FROM checked where status != 0 order by status desc, id asc ");
                while ($row = $checked->fetch_assoc()):
                ?>
                <tr>
                    <td class="text-center">
                        <?php
                        echo isset($row['room_id']) && isset($room_arr[$row['room_id']]['room']) ? $room_arr[$row['room_id']]['room'] : 'Room not found';
                        ?>
                    </td>
                    <td class="text-center">
                        <?php echo isset($row['ref_no']) ? $row['ref_no'] : 'Ref no not found'; ?>
                    </td>
                    <td class="text-center">
                        <?php if ($row['status'] == 1): ?>
                            <span class="badge badge-warning">Checked-IN</span>
                        <?php else: ?>
                            <span class="badge badge-success">Checked-Out</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
