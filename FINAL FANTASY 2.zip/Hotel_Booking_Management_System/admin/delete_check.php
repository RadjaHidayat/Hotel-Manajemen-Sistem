<?php
include('db_connect.php');

// Pastikan request yang diterima adalah POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Periksa apakah ID yang akan dihapus ada dalam request
    if(isset($_POST['id']) && !empty($_POST['id'])) {
        $id = $_POST['id'];

        // Lakukan kueri penghapusan
        $delete_query = $conn->query("DELETE FROM checked WHERE id = '$id'");

        // Periksa apakah penghapusan berhasil
        if($delete_query) {
            echo json_encode(array("status" => "success", "message" => "Data berhasil dihapus"));
        } else {
            echo json_encode(array("status" => "error", "message" => "Gagal menghapus data"));
        }
    } else {
        echo json_encode(array("status" => "error", "message" => "ID tidak valid"));
    }
} else {
    echo json_encode(array("status" => "error", "message" => "Metode request tidak valid"));
}
?>
