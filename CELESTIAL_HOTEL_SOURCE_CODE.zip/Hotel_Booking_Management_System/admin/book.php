<?php
include('db_connect.php');
$rid = '';
$calc_days = abs(strtotime($_GET['out']) - strtotime($_GET['in']));
$calc_days = floor($calc_days / (60 * 60 * 24));
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        /* Add your custom styles for print here */
        @media print {
            body * {
                visibility: hidden;
            }

            #print-form,
            #print-form * {
                visibility: visible;
            }

            #print-form {
                position: absolute;
                left: 0;
                top: 0;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid" id="print-form">

        <form action="" id="manage-check">
            <input type="hidden" name="cid" value="<?php echo isset($_GET['cid']) ? $_GET['cid'] : '' ?>">
            <input type="hidden" name="rid" value="<?php echo isset($_GET['rid']) ? $_GET['rid'] : '' ?>">

            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" name="name" id="name" class="form-control" value="<?php echo isset($meta['name']) ? $meta['name'] : '' ?>" required>
            </div>
            <div class="form-group">
                <label for="contact">Contact</label>
                <input type="text" name="contact" id="contact" class="form-control" value="<?php echo isset($meta['contact_no']) ? $meta['contact_no'] : '' ?>" required>
            </div>
            <div class="form-group">
                <label for="date_in">Check-in Date</label>
                <input type="date" name="date_in" id="date_in" class="form-control"
                    value="<?php echo isset($_GET['in']) ? date("Y-m-d", strtotime($_GET['in'])) : date("Y-m-d") ?>"
                    required readonly>
            </div>
            <div class="form-group">
                <label for="date_in_time">Check-in Time</label>
                <input type="time" name="date_in_time" id="date_in_time" class="form-control"
                    value="<?php echo isset($_GET['date_in']) ? date("H:i", strtotime($_GET['date_in'])) : date("H:i") ?>"
                    required>
            </div>
            <div class="form-group">
                <label for="days">Days of Stay</label>
                <input type="number" min="1" name="days" id="days" class="form-control"
                    value="<?php echo isset($_GET['in']) ? $calc_days : 1 ?>" required readonly>
            </div>

            <!-- Print Data Button with data-id attribute -->
            <button class="btn btn-primary float-right print_data" type="button">Print Data</button>
        </form>
    </div>

	<script>
    $('#manage-check').submit(function (e) {
        e.preventDefault();
        start_load()
        $.ajax({
            url: 'admin/ajax.php?action=save_book',
            method: 'POST',
            data: $(this).serialize(),
            success: function (resp) {
                if (resp > 0) {
                    alert_toast("Data successfully saved", 'success')
                    setTimeout(function () {
                        end_load()
                        $('.modal').modal('hide')
                    }, 1500)
                }
            }
        })
    })

    // Print Data Button Click Event
    $('.print_data').click(function () {
        // Trigger the print functionality
        window.print();

        // Hapus tombol cetak setelah mencetak
        $('.print_data').remove();
    });
</script>
</body>

</html>