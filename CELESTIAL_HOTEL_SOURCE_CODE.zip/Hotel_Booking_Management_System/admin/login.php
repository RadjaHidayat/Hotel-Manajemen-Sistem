<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta content="width=device-width, initial-scale=1.0" name="viewport">
	<title>Admin | Hotel Management System</title>
	<link rel="stylesheet" href="styles.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
	<?php include('./header.php'); ?>
	<?php include('./db_connect.php'); ?>
	<?php
	session_start();
	if (isset($_SESSION['login_id']))
		header("location:index.php?page=home");

	$query = $conn->query("SELECT * FROM system_settings limit 1")->fetch_array();
	foreach ($query as $key => $value) {
		if (!is_numeric($key))
			$_SESSION['setting_' . $key] = $value;
	}
	?>
</head>

<style>
	body {
		width: 100%;
		height: 100%;
		margin: 0;
		padding: 0;
		font-family: Arial, sans-serif;
	}

	main#main {
		width: 100%;
		height: 100%;
		display: flex;
	}

	#login-left {
		position: relative;
		width: 60%;
		height: 100vh;
		/* Menggunakan tinggi layar penuh */
		background: url(../assets/img/<?php echo $_SESSION['setting_cover_img'] ?>);
		background-repeat: no-repeat;
		background-size: cover;
		/* Menyesuaikan gambar untuk mengisi area yang tersedia */
	}


	#login-right {
		position: relative;
		width: 40%;
		background: linear-gradient(45deg, #ff0000, #ff69b4, #808080);
		display: flex;
		align-items: center;
	}

	.card {
		margin: auto;
		width: 80%;
	}

	.logo {
		margin: auto;
		font-size: 8rem;
		background: white;
		padding: 0.5em 0.8em;
		border-radius: 50% 50%;
		color: #000000b3;
	}

	.password-input {
		position: relative;
	}

	.password-input input {
		padding-right: 30px;
		/* Mengatur ruang untuk ikon mata */
	}
</style>

<body>

	<main id="main">
		<div id="login-left"></div>
		<div id="login-right">
			<div class="card">
				<div class="card-body">
					<form id="login-form">
						<div class="form-group">
							<label for="username" class="control-label">
								<i class="fas fa-user"></i> <!-- Ikon user -->
								Username
							</label>
							<input type="text" id="username" name="username" class="form-control">
						</div>
						<div class="form-group">
							<label for="password" class="control-label">
								<i class="fas fa-lock"></i>
								Password
							</label>
							<div class="password-input">
								<input type="password" id="password" name="password" class="form-control">
							</div>
						</div>
						<center>
							<button class="btn btn-sm btn-block btn-primary">Login</button>
						</center>
					</form>
				</div>
			</div>
		</div>
	</main>

	<a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script>
		$('#login-form').submit(function (e) {
			e.preventDefault()
			$('#login-form button[type="button"]').attr('disabled', true).html('Logging in...');
			if ($(this).find('.alert-danger').length > 0)
				$(this).find('.alert-danger').remove();
			$.ajax({
				url: 'ajax.php?action=login',
				method: 'POST',
				data: $(this).serialize(),
				error: err => {
					console.log(err)
					$('#login-form button[type="button"]').removeAttr('disabled').html('Login');
				},
				success: function (resp) {
					if (resp == 1) {
						location.href = 'index.php?page=home';
					} else if (resp == 2) {
						location.href = 'index.php?page=home';
					} else {
						$('#login-form').prepend('<div class="alert alert-danger">Username or password is incorrect.</div>')
						$('#login-form button[type="button"]').removeAttr('disabled').html('Login');
					}
				}
			})
		})
	</script>
</body>

</html>